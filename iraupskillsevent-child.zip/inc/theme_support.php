<?php

/* =================================================
    Activate: Featured image
    20 mar 2017
==================================================== */
	add_theme_support( 'post-thumbnails' );

/* ================================================
	THEMESUPPORT: woocommerce - 23 aug 2017
=================================================== */
    add_theme_support('woocommerce');
